package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.view

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.lightappsdev.cfw2ofwcompatibilitylist.R
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.adapters.GameAdapter
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.interfaces.GameAdapterListener
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.viewmodel.MainActivityViewModel
import com.lightappsdev.cfw2ofwcompatibilitylist.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity(), GameAdapterListener {

    private lateinit var binding: ActivityMainBinding

    private val viewModel: MainActivityViewModel by viewModels()

    private val onBackPressedCallback: OnBackPressedCallback =
        object : OnBackPressedCallback(enabled = true) {
            override fun handleOnBackPressed() {

                val firstVisibleItemPosition =
                    (binding.recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()

                if (firstVisibleItemPosition != 0) {
                    binding.recyclerView.smoothScrollToPosition(0)
                    return
                }

                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        val listener = this

        binding.recyclerView.apply {
            adapter = viewModel.gameAdapter.value?.also { gameAdapter ->
                gameAdapter.listener = listener
                gameAdapter.fragmentManager = supportFragmentManager
            } ?: GameAdapter(listener, supportFragmentManager).also { gameListAdapter ->
                viewModel.gameListAdapter(gameListAdapter)
            }
            setHasFixedSize(true)
        }

        binding.toolbar.apply {
            setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.updateGamesMenu -> viewModel.updateGames()
                }
                return@setOnMenuItemClickListener true
            }
        }

        lifecycleScope.launch {
            launch {
                viewModel.isLoading.collectLatest { isLoading ->
                    binding.linearProgressIndicator.apply {
                        isIndeterminate = isLoading
                        isVisible = isLoading
                    }
                }
            }

            launch {
                viewModel.gameList.collectLatest { list ->
                    if (list.isEmpty()) {
                        viewModel.getListFromRepository()
                        return@collectLatest
                    }

                    viewModel.gameAdapter.value?.list = list
                }
            }

            launch {
                viewModel.updateProgress.collectLatest { updateGamesState ->
                    binding.toolbar.menu?.findItem(R.id.updateGamesMenu)?.isVisible =
                        updateGamesState == null

                    if (updateGamesState == null) {
                        binding.linearProgressIndicator.isVisible = false
                        return@collectLatest
                    }

                    binding.linearProgressIndicator.apply {
                        max = updateGamesState.max
                        progress = updateGamesState.progress
                        isVisible = true
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(onBackPressedCallback)

        setContentView(binding.root)
    }
}