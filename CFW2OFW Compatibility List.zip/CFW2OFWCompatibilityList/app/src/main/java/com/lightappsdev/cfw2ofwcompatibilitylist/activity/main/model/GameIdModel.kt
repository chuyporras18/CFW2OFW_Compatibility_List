package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model

import com.lightappsdev.cfw2ofwcompatibilitylist.R

data class GameIdModel(
    val id: String,
    val gameId: Int,
    val worksByDTU: String,
    val worksByHAN: String,
    val notes: String
) {

    fun getDtuIcon(): Int? {
        return getWorkIcon(worksByDTU)
    }

    fun getHanIcon(): Int? {
        return getWorkIcon(worksByHAN)
    }

    private fun getWorkIcon(s: String): Int? {
        return when (s) {
            "Yes" -> R.drawable.baseline_check_24
            "No" -> R.drawable.baseline_close_24
            "?" -> R.drawable.baseline_question_mark_24
            "Exclusive Method" -> R.drawable.baseline_swap_horiz_24
            else -> null
        }
    }
}

fun GameIdModel.toEntity(): GameIdEntity {
    return GameIdEntity(id, gameId, worksByDTU, worksByHAN, notes)
}