package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model

data class UpdateGamesState(val max: Int = 0, var progress: Int = 0)
