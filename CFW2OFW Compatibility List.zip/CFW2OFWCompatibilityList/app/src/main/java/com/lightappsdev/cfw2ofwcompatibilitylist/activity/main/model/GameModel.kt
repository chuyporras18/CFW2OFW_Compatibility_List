package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model

import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.enums.GameAdapterTypes

data class GameModel(
    val title: String,
    val id: Int = title.hashCode(),
    var images: List<String> = emptyList(),
    val ids: List<GameIdModel> = emptyList(),
    override val viewType: GameAdapterTypes = GameAdapterTypes.GAME
) : GameAdapterModel()

fun GameModel.toEntity(): GameEntity {
    return GameEntity(title, images)
}
