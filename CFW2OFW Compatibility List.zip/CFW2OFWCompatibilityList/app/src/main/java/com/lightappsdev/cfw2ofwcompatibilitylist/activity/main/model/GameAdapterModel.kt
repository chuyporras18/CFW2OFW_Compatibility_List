package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model

import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.enums.GameAdapterTypes

abstract class GameAdapterModel {

    abstract val viewType: GameAdapterTypes
}