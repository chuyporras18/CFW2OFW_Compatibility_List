package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.view.fragments.game_details.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.adapters.GameIdAdapter
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.core.GameListProvider
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FragmentGameDetailsViewModel @Inject constructor(private val gameListProvider: GameListProvider) :
    ViewModel() {

    private val _gameModel: MutableLiveData<GameModel?> = MutableLiveData()
    val gameModel: LiveData<GameModel?> = _gameModel

    private val _gameIdAdapter: MutableLiveData<GameIdAdapter> = MutableLiveData()
    val gameIdAdapter: LiveData<GameIdAdapter> = _gameIdAdapter

    fun getGameData(id: Int?) {
        viewModelScope.launch {
            _gameModel.value = id?.let { gameListProvider.getGameById(it) }
        }
    }

    fun gameIdAdapter(adapter: GameIdAdapter) {
        _gameIdAdapter.value = adapter
    }
}