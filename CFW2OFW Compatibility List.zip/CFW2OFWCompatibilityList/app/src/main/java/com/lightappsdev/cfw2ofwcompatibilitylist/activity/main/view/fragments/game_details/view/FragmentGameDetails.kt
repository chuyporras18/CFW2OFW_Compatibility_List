package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.view.fragments.game_details.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.ListPopupWindow.MATCH_PARENT
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.adapters.GameIdAdapter
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.view.fragments.game_details.viewmodel.FragmentGameDetailsViewModel
import com.lightappsdev.cfw2ofwcompatibilitylist.addForegroundRipple
import com.lightappsdev.cfw2ofwcompatibilitylist.databinding.FragmentGameDetailsBinding
import com.lightappsdev.cfw2ofwcompatibilitylist.load
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FragmentGameDetails : DialogFragment() {

    companion object {
        const val TAG: String = "FragmentGameDetails"
    }

    private var _binding: FragmentGameDetailsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FragmentGameDetailsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentGameDetailsBinding.inflate(inflater, container, false)

        return _binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.gameCover1CV.apply {
            addForegroundRipple()
        }

        binding.gameCover2CV.apply {
            addForegroundRipple()
        }

        binding.recyclerView.apply {
            adapter = viewModel.gameIdAdapter.value ?: GameIdAdapter().also { gameIdAdapter ->
                viewModel.gameIdAdapter(gameIdAdapter)
            }
        }

        viewModel.gameModel.observe(viewLifecycleOwner) { gameModel ->
            if (gameModel == null) {
                dialog?.dismiss()
                return@observe
            }

            binding.gameCover1IV.load(gameModel.images.elementAtOrNull(0))
            binding.gameCover2IV.load(gameModel.images.elementAtOrNull(1))

            binding.gameTitleTV.text = gameModel.title

            viewModel.gameIdAdapter.value?.list = gameModel.ids
        }

        viewModel.getGameData(arguments?.getInt("id"))
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(MATCH_PARENT, MATCH_PARENT)
    }
}