package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.viewmodel

import androidx.core.text.isDigitsOnly
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.adapters.GameAdapter
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.core.GameDataProvider
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.core.GameListProvider
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameAdapterModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameHeaderModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.UpdateGamesState
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.toDomain
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainActivityViewModel @Inject constructor(
    private val gameListProvider: GameListProvider,
    private val gameDataProvider: GameDataProvider
) :
    ViewModel() {

    val gameList: Flow<List<GameAdapterModel>> = gameListProvider.gameList.map { list ->
        val map = mutableMapOf<String, MutableList<GameAdapterModel>>()

        list.forEach { gameWithIdsEntity ->
            val gameModel = gameWithIdsEntity.gameEntity.toDomain()
                .copy(ids = gameWithIdsEntity.gameIdEntity.map { gameIdEntity -> gameIdEntity.toDomain() })

            val firstChar = gameModel.title.first().lowercase()
            val key = if (firstChar.isDigitsOnly()) "#" else firstChar.uppercase()

            if (!map.containsKey(key)) {
                map[key] = mutableListOf(GameHeaderModel(header = key))
            }

            map[key]!!.add(gameModel)
        }

        return@map map.values.flatten()
    }.flowOn(Dispatchers.IO)

    private val _gameAdapter: MutableLiveData<GameAdapter> = MutableLiveData()
    val gameAdapter: LiveData<GameAdapter> = _gameAdapter

    private val _isLoading: MutableStateFlow<Boolean> = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _updateProgress: MutableStateFlow<UpdateGamesState?> = MutableStateFlow(null)
    val updateProgress: StateFlow<UpdateGamesState?> = _updateProgress

    fun getListFromRepository() {
        viewModelScope.launch {
            _isLoading.update { true }

            gameListProvider.getListFromRepository()

            _isLoading.update { false }
        }
    }

    fun updateGames() {
        viewModelScope.launch {
            _updateProgress.value = UpdateGamesState()

            val pendingGames = gameDataProvider.getPendingDataGames()
            val maxProgress = pendingGames.size

            _updateProgress.value = _updateProgress.value?.copy(max = maxProgress)

            pendingGames.forEachIndexed { index, gameModel ->
                println("$index ${gameModel.title}")
                gameDataProvider.fetchGameData(gameModel)
                _updateProgress.value = _updateProgress.value?.copy(progress = index)
            }

            _updateProgress.value = null
        }
    }

    fun gameListAdapter(adapter: GameAdapter) {
        _gameAdapter.value = adapter
    }
}