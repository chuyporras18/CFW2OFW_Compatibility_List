package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.enums

enum class GameAdapterTypes {
    HEADER, GAME
}