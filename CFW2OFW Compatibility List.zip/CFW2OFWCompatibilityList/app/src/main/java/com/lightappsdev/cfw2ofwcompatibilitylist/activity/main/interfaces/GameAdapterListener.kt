package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.interfaces

import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentManager
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.view.fragments.game_details.view.FragmentGameDetails

interface GameAdapterListener {

    fun onClick(gameModel: GameModel, fragmentManager: FragmentManager) {
        FragmentGameDetails().also { fragment ->
            fragment.arguments = bundleOf("id" to gameModel.id)
        }.show(fragmentManager, FragmentGameDetails.TAG)
    }

    fun onClickImage(gameModel: GameModel) {}
}