package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.core

import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.interfaces.GamesDao
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.toDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GameDataProvider @Inject constructor(private val gamesDao: GamesDao) {

    companion object {
        private const val BASE_URL: String = "https://www.gametdb.com/PS3/"
    }

    suspend fun fetchGameData(gameModel: GameModel) {
        withContext(Dispatchers.IO) {
            gameModel.ids.forEach { gameIdModel ->
                val document =
                    Jsoup.connect(BASE_URL + gameIdModel.id).userAgent("Mozilla")
                        .timeout(60 * 1000).get()

                val text = document.getElementById("wikitext")?.text().orEmpty()
                if (text.contains("doesn't exist")) {
                    return@forEach
                }

                val images =
                    document.getElementsByClass("highslide").map { element -> element.attr("href") }

                gameModel.images = images

                insertGame(gameModel)

                return@withContext
            }
        }
    }

    suspend fun getPendingDataGames(): List<GameModel> {
        return withContext(Dispatchers.IO) {
            val list = mutableListOf<GameModel>()

            gamesDao.getAllGames().forEach { gameWithIdsEntity ->
                if (gameWithIdsEntity.gameEntity.images.isEmpty()) {
                    list.add(
                        gameWithIdsEntity.gameEntity.toDomain()
                            .copy(ids = gameWithIdsEntity.gameIdEntity.map { gameIdEntity -> gameIdEntity.toDomain() })
                    )
                }
            }

            return@withContext list.sortedBy { it.title }
        }
    }

    private suspend fun insertGame(gameModel: GameModel) {
        withContext(Dispatchers.IO) {
            gamesDao.insertGame(gameModel)
        }
    }
}