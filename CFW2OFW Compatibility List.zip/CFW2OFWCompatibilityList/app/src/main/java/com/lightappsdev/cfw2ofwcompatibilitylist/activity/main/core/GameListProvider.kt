package com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.core

import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.interfaces.GamesDao
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameIdModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameModel
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.GameWithIdsEntity
import com.lightappsdev.cfw2ofwcompatibilitylist.activity.main.model.toDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GameListProvider @Inject constructor(private val gamesDao: GamesDao) {

    companion object {
        private const val BASE_URL: String =
            "https://www.psdevwiki.com/ps3/CFW2OFW_Compatibility_List"
    }

    val gameList: Flow<List<GameWithIdsEntity>> = gamesDao.getGames().flowOn(Dispatchers.IO)

    suspend fun getListFromRepository() {
        return try {
            withContext(Dispatchers.IO) {
                val games: MutableMap<String, MutableList<GameIdModel>> = mutableMapOf()

                val document = Jsoup.connect(BASE_URL).userAgent("Mozilla").timeout(60 * 1000).get()

                val tables =
                    document.getElementsByClass("wikitable mw-datatable sortable")

                tables.forEach { table ->
                    val tbodies = table.getElementsByTag("tbody")

                    tbodies.forEach { tbody ->
                        val trs = tbody.getElementsByTag("tr").toMutableList()

                        var lastKey: String? = null
                        trs.forEach trs@{ tr ->
                            val tds = tr.getElementsByTag("td").toMutableList()

                            if (tds.isEmpty()) {
                                return@trs
                            }

                            if (tds.size == 5) {
                                lastKey = tds.removeFirst().text()

                                games.getOrPut(lastKey!!) { mutableListOf() }
                            }

                            lastKey?.let { key ->
                                val id = tds[0].text()

                                if (games[key]?.any { gameIdModel -> gameIdModel.id == id } == true) {
                                    return@let
                                }

                                val gameId = lastKey!!.hashCode()
                                val worksByDTU = tds[1].text()
                                val worksByHAN = tds[2].text()
                                val notes = tds[3].text()

                                val gameIdModel =
                                    GameIdModel(id, gameId, worksByDTU, worksByHAN, notes)
                                games[key]!!.add(gameIdModel)
                            }
                        }
                    }
                }

                saveListToDatabase(games.map { (key, value) -> GameModel(key, ids = value) })
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun saveListToDatabase(list: List<GameModel>) {
        withContext(Dispatchers.IO) {
            gamesDao.insertGames(list)
        }
    }

    suspend fun getGameById(id: Int): GameModel? {
        return withContext(Dispatchers.IO) {
            val entity = gamesDao.getGameById(id)
            entity?.gameEntity?.toDomain()
                ?.copy(ids = entity.gameIdEntity.map { it.toDomain() })
        }
    }
}